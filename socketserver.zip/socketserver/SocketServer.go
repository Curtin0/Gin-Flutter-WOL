package main

import (
	"fmt"
	"log"
	"net"
	"os"
	"time"
)

func main() {
	//建立socket端口监听
	netListen, err := net.Listen("tcp", "localhost:20019")
	CheckError(err)

	defer netListen.Close()

	//日志功能，服务端能看到在运行
	Log("Waiting for clients ...")

	//等待客户端访问
	for {
		conn, err := netListen.Accept() //监听接收
		if err != nil {
			continue //如果发生错误，继续下一个循环。
		}

		Log(conn.RemoteAddr().String(), "tcp connect success") //tcp连接成功

		//处理连接任务 接收客户端信息和反馈给客户端信息
		go handleConnection(conn)
	}
}

//处理连接 来自主函数
func handleConnection(conn net.Conn) {
	buffer := make([]byte, 2048) //建立一个slice
	for {
		n, err := conn.Read(buffer) //读取客户端传来的内容 buffer缓冲器 包含读写操作

		//fmt.Printf(string(buffer))

		if err != nil {
			Log(conn.RemoteAddr().String(), "connection error: ", err)
			return //当远程客户端连接发生错误（断开）后，终止此协程。
		}

		Log(conn.RemoteAddr().String(), "receive data string:\n", string(buffer[:n]))

		//返回给客户端的信息
		strTemp := "CofoxServer got msg \"" + string(buffer[:n]) + "\" at " + time.Now().String()
		conn.Write([]byte(strTemp))

		//还需要通过websocket发送给前端

	}
}

//日志处理
func Log(v ...interface{}) {
	log.Println(v...)
}

//错误处理
func CheckError(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "Fatal error: %s", err.Error())
	}
}
